function plot_svm(x_train,y_train,x_test,y_test,theta)
%% Arguments %%
% x_train: training data
% y_train: training label
% x_test: test data
% y_test: test label
% theta: weight parameter
%% Your code here %%



end