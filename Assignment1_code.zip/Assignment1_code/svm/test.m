function [acc] = test(x_test,y_test,theta)
%% Argurments %%
% x_test: test data
% y_test: test label
% theta: weight parameter
% acc: accuracy
%% Your code here %%



end